#!/usr/bin/env bash
# scripts/deploy-relay.sh (stub)
set -euo pipefail
ENV=${1:-staging}
echo "Deploying relay to ${ENV} (stub). Replace this script with CI deploy steps."
