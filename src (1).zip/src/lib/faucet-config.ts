export const FAUCET_AMOUNTS = {
  userRequest: 1_000_000, // 1 ALGO
};

export const ALGORAND_MIN_TX_FEE = 1000;

export const NETWORK_COOLDOWN_TIME = 24 * 60 * 60 * 1000; // 24 hours
