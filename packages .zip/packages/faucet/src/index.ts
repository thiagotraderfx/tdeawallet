"use client";

import FaucetClient from "./components/FaucetClient";

export { FaucetClient as default };
